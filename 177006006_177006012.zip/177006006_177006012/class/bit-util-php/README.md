Binary Utility Library for PHP
==============================

A collection of simple utilities for working with binary data in php. Of course, the existence of this code 
does not suggest its (or PHP's) suitability for any particular purpose. These utilities came from
[CodeKata](http://codekata.pragprog.com/) exercises, not real development projects.

